#!/usr/bin/env bash
# =============================================================================
# deploy-rclone-idrivee2.sh
# Deploy & configure rclone for iDrive E2 (S3-compatible) on Ubuntu/Debian
#
# Usage:
#   chmod +x deploy-rclone-idrivee2.sh
#   ./deploy-rclone-idrivee2.sh
#
# Env vars (set before running, or the script will prompt):
#   IDRIVEE2_ACCESS_KEY    — iDrive E2 Access Key ID
#   IDRIVEE2_SECRET_KEY    — iDrive E2 Secret Access Key
#   IDRIVEE2_ENDPOINT      — iDrive E2 endpoint URL (from your iDrive E2 console)
#                            e.g. https://w0l83.la12.idrivee2-5.com
#   IDRIVEE2_REGION        — Region (default: us-east-1 — iDrive E2 accepts any value)
#   IDRIVEE2_REMOTE_NAME   — rclone remote name (default: idrivee2)
# =============================================================================

set -euo pipefail

# ── Color helpers ─────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║       rclone × iDrive E2 Deployment Script              ║${NC}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

# ── Collect credentials ───────────────────────────────────────────────────────
REMOTE_NAME="${IDRIVEE2_REMOTE_NAME:-idrivee2}"

if [[ -z "${IDRIVEE2_ACCESS_KEY:-}" ]]; then
    read -rp "  iDrive E2 Access Key ID: " IDRIVEE2_ACCESS_KEY
fi
if [[ -z "${IDRIVEE2_SECRET_KEY:-}" ]]; then
    read -rsp "  iDrive E2 Secret Access Key: " IDRIVEE2_SECRET_KEY
    echo ""
fi
if [[ -z "${IDRIVEE2_ENDPOINT:-}" ]]; then
    echo ""
    info "Find your endpoint in the iDrive E2 Console → Buckets → Endpoint."
    info "Format: https://<account-id>.idrivee2-<N>.com"
    read -rp "  iDrive E2 Endpoint URL: " IDRIVEE2_ENDPOINT
fi
IDRIVEE2_REGION="${IDRIVEE2_REGION:-us-east-1}"

echo ""
info "Remote name : ${REMOTE_NAME}"
info "Endpoint    : ${IDRIVEE2_ENDPOINT}"
info "Region      : ${IDRIVEE2_REGION}"
echo ""

# ── 1. Install / upgrade rclone ───────────────────────────────────────────────
info "Step 1: Installing / upgrading rclone..."

if command -v rclone &>/dev/null; then
    CURRENT=$(rclone version 2>/dev/null | head -1 | awk '{print $2}')
    info "Current rclone version: ${CURRENT}"
fi

# Always install latest stable from official script
curl -fsSL https://rclone.org/install.sh | sudo bash
RCLONE_BIN=$(command -v rclone)
RCLONE_VER=$(rclone version | head -1)
success "rclone installed: ${RCLONE_VER} → ${RCLONE_BIN}"

# ── 2. Write rclone config ────────────────────────────────────────────────────
info "Step 2: Writing rclone config..."

RCLONE_CONFIG_DIR="${HOME}/.config/rclone"
RCLONE_CONFIG_FILE="${RCLONE_CONFIG_DIR}/rclone.conf"
mkdir -p "${RCLONE_CONFIG_DIR}"

# Remove existing stanza if present
if grep -q "^\[${REMOTE_NAME}\]" "${RCLONE_CONFIG_FILE}" 2>/dev/null; then
    warn "Existing [${REMOTE_NAME}] stanza found — replacing it."
    # Remove the stanza (from [remotename] to next blank line or EOF)
    python3 - "${RCLONE_CONFIG_FILE}" "${REMOTE_NAME}" <<'PYEOF'
import sys, re
path, name = sys.argv[1], sys.argv[2]
with open(path, 'r') as f:
    content = f.read()
pattern = re.compile(r'^\[' + re.escape(name) + r'\][^\[]*', re.MULTILINE)
content = pattern.sub('', content).strip() + '\n'
with open(path, 'w') as f:
    f.write(content)
PYEOF
fi

# Append new stanza
cat >> "${RCLONE_CONFIG_FILE}" <<CONF

[${REMOTE_NAME}]
type = s3
provider = IDriveE2
access_key_id = ${IDRIVEE2_ACCESS_KEY}
secret_access_key = ${IDRIVEE2_SECRET_KEY}
endpoint = ${IDRIVEE2_ENDPOINT}
region = ${IDRIVEE2_REGION}
acl = private
no_check_bucket = false
force_path_style = false
upload_concurrency = 4
chunk_size = 64M
copy_cutoff = 64M
CONF

success "Config written: ${RCLONE_CONFIG_FILE}"

# ── 3. Verify connection ──────────────────────────────────────────────────────
info "Step 3: Testing connection..."

if rclone lsd "${REMOTE_NAME}:" --max-depth 1 2>&1; then
    success "Connection to iDrive E2 successful!"
else
    warn "Could not list buckets. Check your credentials and endpoint."
    warn "Try manually: rclone lsd ${REMOTE_NAME}:"
fi

# ── 4. Create helper scripts ──────────────────────────────────────────────────
SCRIPTS_DIR="${HOME}/.local/bin"
mkdir -p "${SCRIPTS_DIR}"

# sync-to-e2.sh
cat > "${SCRIPTS_DIR}/sync-to-e2.sh" <<'SYNCSCRIPT'
#!/usr/bin/env bash
# sync-to-e2.sh <local_dir> <bucket_name> [rclone_flags...]
# Syncs a local directory to an iDrive E2 bucket.
set -euo pipefail
LOCAL="${1:?Usage: sync-to-e2.sh <local_dir> <bucket_name> [flags...]}"
BUCKET="${2:?provide bucket name}"
shift 2
REMOTE_NAME="${IDRIVEE2_REMOTE_NAME:-idrivee2}"
echo "Syncing ${LOCAL} → ${REMOTE_NAME}:${BUCKET}"
rclone sync \
    --progress \
    --transfers 4 \
    --checkers 8 \
    --s3-upload-concurrency 4 \
    --s3-chunk-size 64M \
    "${LOCAL}/" \
    "${REMOTE_NAME}:${BUCKET}/" \
    "$@"
echo "Done."
SYNCSCRIPT
chmod +x "${SCRIPTS_DIR}/sync-to-e2.sh"

# backup-to-e2.sh (copy, keeps source)
cat > "${SCRIPTS_DIR}/backup-to-e2.sh" <<'BACKUPSCRIPT'
#!/usr/bin/env bash
# backup-to-e2.sh <local_dir> <bucket_name/prefix> [rclone_flags...]
set -euo pipefail
LOCAL="${1:?Usage: backup-to-e2.sh <local_dir> <bucket/prefix> [flags...]}"
DEST="${2:?provide destination bucket/prefix}"
shift 2
REMOTE_NAME="${IDRIVEE2_REMOTE_NAME:-idrivee2}"
TIMESTAMP=$(date +%Y-%m-%dT%H-%M)
echo "Backup ${LOCAL} → ${REMOTE_NAME}:${DEST}/${TIMESTAMP}/"
rclone copy \
    --progress \
    --transfers 4 \
    --checkers 8 \
    "${LOCAL}/" \
    "${REMOTE_NAME}:${DEST}/${TIMESTAMP}/" \
    "$@"
echo "Backup complete: ${REMOTE_NAME}:${DEST}/${TIMESTAMP}/"
BACKUPSCRIPT
chmod +x "${SCRIPTS_DIR}/backup-to-e2.sh"

# mount-e2.sh
cat > "${SCRIPTS_DIR}/mount-e2.sh" <<'MOUNTSCRIPT'
#!/usr/bin/env bash
# mount-e2.sh <bucket_name> <mountpoint>
set -euo pipefail
BUCKET="${1:?provide bucket name}"
MOUNTPOINT="${2:?provide mountpoint}"
REMOTE_NAME="${IDRIVEE2_REMOTE_NAME:-idrivee2}"
mkdir -p "${MOUNTPOINT}"
echo "Mounting ${REMOTE_NAME}:${BUCKET} → ${MOUNTPOINT}"
rclone mount \
    "${REMOTE_NAME}:${BUCKET}" \
    "${MOUNTPOINT}" \
    --vfs-cache-mode writes \
    --vfs-cache-max-size 2G \
    --allow-other \
    --daemon
echo "Mounted. Unmount with: fusermount -u ${MOUNTPOINT}"
MOUNTSCRIPT
chmod +x "${SCRIPTS_DIR}/mount-e2.sh"

success "Helper scripts written to ${SCRIPTS_DIR}/"

# ── 5. (Optional) Systemd service for rclone mount ───────────────────────────
info "Step 5: Creating optional systemd mount service template..."

SYSTEMD_DIR="${HOME}/.config/systemd/user"
mkdir -p "${SYSTEMD_DIR}"

cat > "${SYSTEMD_DIR}/rclone-idrivee2@.service" <<UNIT
[Unit]
Description=rclone iDrive E2 mount for bucket %i
After=network-online.target
Wants=network-online.target

[Service]
Type=notify
ExecStartPre=/bin/mkdir -p %h/mnt/idrivee2/%i
ExecStart=${RCLONE_BIN} mount \\
    ${REMOTE_NAME}:%i \\
    %h/mnt/idrivee2/%i \\
    --config=${RCLONE_CONFIG_FILE} \\
    --vfs-cache-mode=writes \\
    --vfs-cache-max-size=2G \\
    --allow-other \\
    --log-level=INFO \\
    --log-file=%h/.local/share/rclone-idrivee2.log
ExecStop=/bin/fusermount -u %h/mnt/idrivee2/%i
Restart=on-failure
RestartSec=10s

[Install]
WantedBy=default.target
UNIT

success "Systemd template: ${SYSTEMD_DIR}/rclone-idrivee2@.service"
info "Enable a bucket mount with:"
info "  systemctl --user enable --now rclone-idrivee2@YOUR_BUCKET_NAME"

# ── 6. Podman container config ────────────────────────────────────────────────
info "Step 6: Writing Podman quadlet for rclone mount (optional)..."

QUADLET_DIR="${HOME}/.config/containers/systemd"
mkdir -p "${QUADLET_DIR}"

cat > "${QUADLET_DIR}/rclone-e2-mount.container" <<QUADLET
[Unit]
Description=rclone iDrive E2 mount (Podman)
After=network-online.target

[Container]
Image=rclone/rclone:latest
AutoUpdate=registry
Volume=${RCLONE_CONFIG_FILE}:/config/rclone/rclone.conf:ro
Volume=%h/mnt/idrivee2:/data:shared
SecurityLabelDisable=true
Capabilities=SYS_ADMIN
Device=/dev/fuse
Environment=RCLONE_CONFIG=/config/rclone/rclone.conf
Exec=mount ${REMOTE_NAME}:BUCKET_NAME /data --vfs-cache-mode writes --allow-other --allow-non-empty

[Service]
Restart=on-failure
TimeoutStartSec=30

[Install]
WantedBy=default.target
QUADLET

success "Quadlet template: ${QUADLET_DIR}/rclone-e2-mount.container"
warn "Edit BUCKET_NAME in the quadlet before enabling."

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║  ✅  rclone iDrive E2 deployment complete                ║${NC}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${CYAN}Remote:${NC}    ${REMOTE_NAME}:"
echo -e "  ${CYAN}Endpoint:${NC}  ${IDRIVEE2_ENDPOINT}"
echo ""
echo -e "  ${BOLD}Quick commands:${NC}"
echo -e "  rclone lsd ${REMOTE_NAME}:                                  # list buckets"
echo -e "  rclone ls  ${REMOTE_NAME}:BUCKET                           # list files"
echo -e "  rclone copy /local/dir ${REMOTE_NAME}:BUCKET/ --progress   # upload"
echo -e "  rclone sync ${REMOTE_NAME}:BUCKET/ /local/dir --progress   # download/sync"
echo -e "  rclone size ${REMOTE_NAME}:BUCKET                          # storage used"
echo -e "  rclone check /local/dir ${REMOTE_NAME}:BUCKET              # verify integrity"
echo ""
echo -e "  ${BOLD}Helper scripts (add ${SCRIPTS_DIR} to PATH):${NC}"
echo -e "  sync-to-e2.sh   <local_dir>  <bucket>   # one-way sync"
echo -e "  backup-to-e2.sh <local_dir>  <bucket>   # timestamped backup"
echo -e "  mount-e2.sh     <bucket>     <mountpoint>"
echo ""
