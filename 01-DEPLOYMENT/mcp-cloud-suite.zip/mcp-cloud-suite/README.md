# Cloud MCP Suite — Nexus Deployment Guide

Five FastMCP Python servers + rclone iDrive E2.  
All servers use `streamable_http` transport on `127.0.0.1`, reverse-proxied by NPM.

---

## Port Map

| Service       | Container Name   | Port  | Subdomain                          |
|---------------|-----------------|-------|------------------------------------|
| pCloud        | `pcloud-mcp`    | 8201  | `pcloud-mcp.shannonjlove.cloud`    |
| Backblaze B2  | `backblaze-mcp` | 8202  | `b2-mcp.shannonjlove.cloud`        |
| MediaFire     | `mediafire-mcp` | 8203  | `mediafire-mcp.shannonjlove.cloud` |
| MEGA          | `mega-mcp`      | 8204  | `mega-mcp.shannonjlove.cloud`      |
| Google Drive  | `gdrive-mcp`    | 8205  | `gdrive-mcp.shannonjlove.cloud`    |
| rclone/iDrive | host-level      | —     | iDrive E2 (S3 endpoint)            |

---

## Quick Deploy

```bash
# 1. Clone / SCP this suite to Nexus
scp -r mcp-cloud-suite/ shannon@nexus.shannonjlove.cloud:/opt/mcp-suite/

# 2. Run the master deploy script
cd /opt/mcp-suite/mcp-cloud-suite
chmod +x deploy-cloud-mcp-suite.sh
./deploy-cloud-mcp-suite.sh

# 3. Fill in credentials for each service
vim /opt/mcp-servers/pcloud/pcloud.env
vim /opt/mcp-servers/backblaze/backblaze.env
vim /opt/mcp-servers/mediafire/mediafire.env
vim /opt/mcp-servers/mega/mega.env
vim /opt/mcp-servers/gdrive/gdrive.env

# 4. Restart each container after filling in creds
for svc in pcloud-mcp backblaze-mcp mediafire-mcp mega-mcp gdrive-mcp; do
  systemctl --user restart "$svc"
done

# 5. Deploy rclone for iDrive E2
export IDRIVEE2_ACCESS_KEY=YOUR_KEY
export IDRIVEE2_SECRET_KEY=YOUR_SECRET
export IDRIVEE2_ENDPOINT=https://YOUR_ACCOUNT.idrivee2-N.com
bash rclone-idrivee2/deploy-rclone-idrivee2.sh
```

---

## Credentials Reference

### pCloud
- Get OAuth2 token: https://docs.pcloud.com/methods/auth/
- `PCLOUD_ACCESS_TOKEN` — Long-lived OAuth2 bearer token
- `PCLOUD_REGION` — `us` (default) or `eu`

### Backblaze B2
- Console: https://secure.backblaze.com/app_keys.htm
- `B2_APPLICATION_KEY_ID` — Application Key ID  
- `B2_APPLICATION_KEY` — Application Key (secret)

### MediaFire
- Developer portal: https://www.mediafire.com/developer/
- `MEDIAFIRE_APP_ID` — Your Application ID
- `MEDIAFIRE_API_KEY` — Your API Key
- `MEDIAFIRE_EMAIL` + `MEDIAFIRE_PASSWORD` — Account credentials

### MEGA
- No API key needed — uses email/password
- `MEGA_EMAIL` + `MEGA_PASSWORD` — Account credentials

### Google Drive (local server)
**Option A — Service Account** (recommended for server):
1. GCP Console → IAM → Service Accounts → Create
2. Enable Google Drive API
3. Download JSON key → place in `/opt/mcp-servers/gdrive/credentials/service-account.json`
4. Share folders/drives with the service account email

**Option B — OAuth2**:
1. GCP Console → APIs → Credentials → Create OAuth 2.0 Client ID (Desktop)
2. Download → `/opt/mcp-servers/gdrive/credentials/credentials.json`
3. First run will open browser for auth → generates `token.json`

### iDrive E2 (rclone)
1. iDrive E2 Console → Access Keys → Create Key
2. Note your Endpoint URL under Buckets

---

## NPM Proxy Host Setup (for each server)

In the NPM Admin UI (`https://admin.shannonjlove.cloud`):

1. **Proxy Hosts → Add Proxy Host**
2. Domain Names: (see Port Map above)
3. Scheme: `http`
4. Forward Hostname: `127.0.0.1`
5. Forward Port: (see Port Map above)
6. Websockets Support: ✅ ON
7. Block Exploits: ✅ ON
8. **SSL tab** → Request new certificate → Force SSL → HSTS ✅

---

## Claude Desktop MCP Config

Add to `~/.config/claude-desktop/mcp_servers.json`:

```json
{
  "mcpServers": {
    "pcloud": {
      "url": "https://pcloud-mcp.shannonjlove.cloud/mcp",
      "transport": "streamable_http"
    },
    "backblaze": {
      "url": "https://b2-mcp.shannonjlove.cloud/mcp",
      "transport": "streamable_http"
    },
    "mediafire": {
      "url": "https://mediafire-mcp.shannonjlove.cloud/mcp",
      "transport": "streamable_http"
    },
    "mega": {
      "url": "https://mega-mcp.shannonjlove.cloud/mcp",
      "transport": "streamable_http"
    },
    "gdrive-local": {
      "url": "https://gdrive-mcp.shannonjlove.cloud/mcp",
      "transport": "streamable_http"
    }
  }
}
```

---

## Useful Commands

```bash
# Status
systemctl --user status pcloud-mcp backblaze-mcp mediafire-mcp mega-mcp gdrive-mcp

# Logs (live)
journalctl --user -u pcloud-mcp -f
journalctl --user -u backblaze-mcp -f

# Restart all
for svc in pcloud-mcp backblaze-mcp mediafire-mcp mega-mcp gdrive-mcp; do
  systemctl --user restart "$svc"
done

# Test MCP endpoint
curl -s https://pcloud-mcp.shannonjlove.cloud/mcp | jq .

# rclone — iDrive E2
rclone lsd idrivee2:                          # list buckets
rclone ls idrivee2:BUCKET --max-depth 2       # list files
rclone copy /local/path idrivee2:BUCKET/ -P   # upload
rclone sync idrivee2:BUCKET/ /local/path -P   # sync down
rclone size idrivee2:BUCKET                   # storage used
rclone check /local/path idrivee2:BUCKET      # integrity check
```

---

## Tools by Server

### pcloud_mcp
`pcloud_get_user_info` · `pcloud_list_folder` · `pcloud_get_file_info`  
`pcloud_create_folder` · `pcloud_delete_file` · `pcloud_delete_folder`  
`pcloud_rename_file` · `pcloud_move_file` · `pcloud_copy_file`  
`pcloud_search_files` · `pcloud_get_public_link` · `pcloud_upload_file` · `pcloud_download_file`

### backblaze_mcp
`b2_get_account_info` · `b2_list_buckets` · `b2_list_files` · `b2_get_file_info`  
`b2_create_bucket` · `b2_delete_bucket` · `b2_delete_file` · `b2_hide_file`  
`b2_copy_file` · `b2_upload_file` · `b2_download_file`

### mediafire_mcp
`mf_get_user_info` · `mf_list_folder` · `mf_get_file_info` · `mf_get_download_link`  
`mf_create_folder` · `mf_delete_file` · `mf_delete_folder`  
`mf_move_files` · `mf_copy_files` · `mf_rename_file`  
`mf_search` · `mf_update_privacy` · `mf_upload_file`

### mega_mcp
`mega_get_storage_info` · `mega_list_files` · `mega_find_file`  
`mega_upload_file` · `mega_download_file` · `mega_create_folder`  
`mega_delete_node` · `mega_export_link` · `mega_move_node` · `mega_rename_node`

### gdrive_mcp
`gdrive_get_about` · `gdrive_list_folder` · `gdrive_search` · `gdrive_get_file_info`  
`gdrive_create_folder` · `gdrive_upload_file` · `gdrive_download_file`  
`gdrive_delete_file` · `gdrive_move_file` · `gdrive_copy_file`  
`gdrive_rename_file` · `gdrive_share_file`

---

## File Naming Convention

All new files created by upload tools follow your canonical convention:
`YYYY-MM-DD_HH-MM_category-subcategory_description_UUID24.ext`

Apply via the `rename_to` / `dest_key` parameters on upload tools.
